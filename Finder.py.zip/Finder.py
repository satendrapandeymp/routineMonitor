from glob import glob
import os

listOfAllTheFiles = []

def appendAllFilesFromThisFolder(folderName):
    preprocessedFolderName = os.path.join(folderName, "*")
    listOfFilesAndFolders = glob(preprocessedFolderName)
    for fileOrFolderName in listOfFilesAndFolders:
        if os.path.isdir(fileOrFolderName):
            appendAllFilesFromThisFolder(fileOrFolderName)
        else:
            listOfAllTheFiles.append(fileOrFolderName)

appendAllFilesFromThisFolder(os.getcwd())

for fileName in listOfAllTheFiles:
    print fileName
